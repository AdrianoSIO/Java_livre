/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pj_livre;

/**
 *
 * @author razanateraa
 */
public class CL_connexion {
    public static String url = "//falbala.futaie.org:3306/razanateraa_livre";
    public static String login="razanateraa";
    public static String password="Yiechaizo8ie";
            
    
}
